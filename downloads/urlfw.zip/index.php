<?
header("location:http://uch.your-domain-name.com/space.php?domain=".$_GET['name']);
?>